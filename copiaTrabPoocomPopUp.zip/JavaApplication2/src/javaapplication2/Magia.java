/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

/**
 *
 * @author beatr
 */
public class Magia implements Arma_IF{
    int desm;
    @Override
    public int usarArma() {
        desm = Game.aleatorio(1, 15);
        return desm;
    }

}
