/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

//import java.util.Scanner;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author alunolab08
 */
public class LutSumo extends Pessoa{
    String armamento, fEfeito;
    Icon ic4 = new ImageIcon("sumo.png");
     
    @Override
    void desenhar() {
        System.out.println("DESENHANDO: LUTSUMO");
        System.out.println("                    ::::                ");
        System.out.println("                  .~~!!!~               ");
        System.out.println("                 .:^^~~^^:..            ");
        System.out.println("              :^!!7???????77!.          ");
        System.out.println("    ^J7~.   .^~~~~~~~~~~~~~!!77?JJ:     ");
        System.out.println("    .^!?:!????JJYYYY555PPPPPPPP5YJ:     ");
        System.out.println("      .^.?YYYJJJJJJ????7777~:^~~!~      ");
        System.out.println("   ^?J7:.^:..~YPPPGGBB##&&#Y!~~7?:      ");
        System.out.println("    .:.  ^.7PB&&B#&@&@@&&#P5#&#P7.~     ");
        System.out.println("        ?#:P&&&#!!#&&##&&#?J&&&@P:&7    ");
        System.out.println("        :?:7&#BBJ5@&B??B&@YJBB&@7^J:    ");
        System.out.println("            5#GGGB&&&&&&&&BGGG#Y        ");
        System.out.println("            ^YG#&&&&&&&&&&&&&B7         ");
        System.out.println("              .7YG#&&&&&&#B57.          ");
        System.out.println("             !5GY?77?????7?YG5!         ");
        System.out.println("           ^P##B###BBGGBB#####&P:       ");
        System.out.println("          ^B#B~Y#########&##&!Y&B^      ");
        System.out.println("          5##B.5&5G&&&&&&&5B&!!&&P      ");
        System.out.println("          ^7?7.!?????????????:^??^      ");
      }
    @Override
    String falar(){
        fEfeito = JOptionPane.showInputDialog (null , "Digite a frase de efeito do Lutador de Sumo: ", "Frase Lutador de Sumo" , JOptionPane.QUESTION_MESSAGE, ic4, null, null).toString();
        return fEfeito;
    }
    @Override
    String arma() {
        return armamento;
    }
    @Override
    void setArma(String armamento) {
        this.armamento = armamento;
    }  
    @Override
    int correr(int AS, int num1, int num2) {
        int T = Game.aleatorio(((num1+1)), (num2)) / 10;
        int V = AS * T;
        int A = V * T;
        //V = AS/AT
        // A = AV/AT
        return A;
    }
    
    @Override
    int habilidadeNO() {
        int h = 4;
       return h;
    }
    
}
