/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

//import java.util.Scanner;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 *
 * @author alunolab08
 */
public class Soldado extends Pessoa{
    String armamento, fEfeito;
    Icon ic3 = new ImageIcon("soldado.png");
    
    @Override
    void desenhar() {
        System.out.println("DESENHANDO: SOLDADO");
        System.out.println("               .^.:^^^:.                ");
        System.out.println("             :J5J:~!!!!.??^             ");
        System.out.println("            .7J~^:^~^^:~~!?:            ");
        System.out.println("           .^::^~:~^^~.~~^:^.           ");
        System.out.println("           ^~~~^^.::::.^^^~~:           ");
        System.out.println("           ~~:~~~^^^^^^~~~:~~           ");
        System.out.println("           :::7GPPGGGPPPP7:::           ");
        System.out.println("             7^YBBGPPGBBY^!             ");
        System.out.println("              :.7YY??YY7.:              ");
        System.out.println("                 .^~~^.                 ");
        System.out.println("                .~^^^^^.                ");
        System.out.println("          :!J:^~^^^^::::~^.J!:          ");
        System.out.println("        .:7??:~!!JP55PY!!~:??7:.        ");
        System.out.println("       ^!:.~.:!!!J5555J!!!:.~.:!^       ");
        System.out.println("      ^!!~::.~!!^~~~~~~^!!~::.~!!^      ");
        System.out.println("      ~!!^:J^^!.JPPJJPPJ.!^^J^^!!~      ");
        System.out.println("      ~!!~:7:^!:~??77??~:!~:7:~!!~      ");
        System.out.println("      ~!!!.7.!7^^??????^^!!.7.!!!~      ");
        System.out.println("      ^^^^.!.^^^::::::::^^^.!.^^^^      ");

      }

    @Override
    String falar(){
        fEfeito = JOptionPane.showInputDialog (null , "Digite a frase de efeito do Soldado: ", "Frase Soldado" , JOptionPane.QUESTION_MESSAGE, ic3, null, null).toString();
        return fEfeito;
    }
    
    @Override
    String arma() {
        return armamento;
    }
    
    @Override
    void setArma(String armamento) {
        this.armamento = armamento;
    }  

    @Override
    int correr(int AS, int num1, int num2) {
        int T = Game.aleatorio(((num1+2)), (num2/100)) /10;
        int V = AS * T;
        int A = V * T;
        //V = AS/AT
        // A = AV/AT
        return A;
    }
    
    
    @Override
    int habilidadeNO() {
        int h = 4;
       return h;
    }
    
}
