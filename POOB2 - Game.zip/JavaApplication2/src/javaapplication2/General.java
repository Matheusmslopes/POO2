/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author alunolab08
 */
public class General extends Pessoa{
    String arma, fEfeito;
    Game jogG = new Game();
    
    @Override
    void desenhar() {
        System.out.println("DESENHAR: GENERAL");
      }
    @Override
    String falar() {
        System.out.println("Digite a frase de efeito do General");
        Scanner f = new Scanner(System.in);
        fEfeito = f.next();
        return null;
    }
    @Override
    String arma() {
        System.out.println("ARMA: GENERAL");
        return arma;
    }
    @Override
    String setArma() {
        arma = jogG.escolhaArma();
        //System.out.println("SET DESENHAR: GENERAL");
        return null;
    }    
    @Override
    void correr() {
        System.out.println("CORRER: GENERAL");
    }
    
    @Override
    int habilidadeNO() {
        int h = 6;
       return h;
    }
}
