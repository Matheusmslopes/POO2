/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

/**
 *
 * @author alunolab08
 */
public class Dragao extends Personagem{
    String arma;
    Game jogD = new Game();
    
   @Override
    void desenhar() {
        System.out.println("DESENHAR: DRAGAO");
      }
    @Override
    String arma() {
        System.out.println("ARMA: DRAGAO");
        return arma;
    }
    @Override
    String setArma() {
        arma = jogD.escolhaArma();
        //System.out.println("SET ARMA: DRAGAO");
       return null;
    }    
    void voar(){
        System.out.println("VOAR: DRAGAO");
    }
    
    @Override
    int habilidadeNO() {
        int h = 8;
       return h;
    }
}
