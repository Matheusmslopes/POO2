/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author alunolab08
 */
public class LutSumo extends Pessoa{
    String arma, fEfeito;
    Game jogLS = new Game();
    @Override
    void desenhar() {
        System.out.println("DESENHAR: LUTSUMO");
      }
    @Override
     String falar() {
        System.out.println("Digite a frase de efeito do General");
        Scanner f = new Scanner(System.in);
        fEfeito = f.next();
        return null;
    }
    @Override
    String arma() {
        System.out.println("ARMA: LUTSUMO");
        return arma;
    }
    @Override
    String setArma() {
        arma = jogLS.escolhaArma();
        //System.out.println("SET ARMA: LUTSUMO");
        return null;
    }
    @Override
    void correr() {
        System.out.println("CORRER: LUTSUMO");
    }
    
    @Override
    int habilidadeNO() {
        int h = 4;
       return h;
    }
}
