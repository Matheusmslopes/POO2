/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author beatr
 */
public class Magia implements Arma_IF{
    int at= 0;
    public int usarArma() {
        int desm = Game.aleatorio(1, 15);
        return desm;
    }

    @Override
    public int ataque() {
        int defenido = usarArma();
        Scanner no = new Scanner(System.in);
        int num = no.nextInt();
        at = defenido * (num/Game.aleatorio(1, 6));
        return at;
    }
}
