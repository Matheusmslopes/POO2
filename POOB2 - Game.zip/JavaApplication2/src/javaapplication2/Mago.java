/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

import java.util.Scanner;

/**
 *
 * @author alunolab08
 */
public class Mago extends Pessoa{
    String arma;
    String fEfeito;
    Game jogM = new Game();

    @Override //IMAGEM ASCII
    void desenhar() {
    System.out.println("DESENHANDO MAGO: ");
    System.out.println("                                                  @@@                                                ");
    System.out.println("                                                 @@@@@                                               ");
    System.out.println("                                                @@  *@@                                              ");
    System.out.println("                                               @@    %@@                                             ");
    System.out.println("                                              @@      @@%                                            ");
    System.out.println("                                             @@        @@*                                           ");
    System.out.println("                                            @@          @@=                                          ");
    System.out.println("                                           @@            @@.  			            ");
    System.out.println("                                          @@              @@                                         ");
    System.out.println("                                         @@                @@                                        ");
    System.out.println("                                        @@                  @@                                       ");
    System.out.println("                                       @@                    @@                                      ");
    System.out.println("                                      @@@         :=         @@@                                     ");
    System.out.println("                                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                                ");
    System.out.println("                      %@@@@@@%                                       @@@@@                           ");
    System.out.println("                   @@@@%                                                   @@@@+                     ");
    System.out.println("                @@@:                 #@@@@@@@@@@@@@@@@@@@@@@@                  @@@                   ");
    System.out.println("              @@@                  @@@#                    -@@@                   @@                 ");
    System.out.println("             @@=                   @@                         @@                   @@                ");
    System.out.println("             @@:                  @@      =%          =%      @@                   @@                ");
    System.out.println("              @@+               @@@@    @@@@@@@    .@@@@@@@   @@@@#               @@                 ");
    System.out.println("               @@@           :@@%@@                          @@@%@@           #@@%                   ");
    System.out.println("                 #@@@@       @@  @              @             @  @@       #@@@@                      ");
    System.out.println("                     =@@@@@@@@@        @@@@@@@ @@  @@@@@@@       @@@@@@@@@@                          ");
    System.out.println("                            @@@@     @@      @@@@@@      @@      @@@=                                ");
    System.out.println("                              @@    @@         @@@        @@@   @@         @@%                       ");
    System.out.println("                               @@.*@@         @@@@          @@ @@       +@@  @@@                     ");
    System.out.println("                                @@@          @@: @@          @@@@       @@     @@                    ");
    System.out.println("                             @@@@@           @@    @@           @@@@@-  %@@     @@                   ");
    System.out.println("                             @@@@         @@@      =@@          @@@*    @@    @@                     ");
    System.out.println("                               :@@@@@@@@@@@          *@@@@@@@@@@@         @@@@@                      ");
    System.out.println("             :@@                    @@                    -@@              @@                        ");
    System.out.println("              @@                    @@                     @@            @@@@@@                      ");
    System.out.println("              @@%                  @@@                     @@              @@:                       ");
    System.out.println("               @@                  @@@@                   %@@              @@                        ");
    System.out.println("               @@                  @@@@+                  @@@@             @@                        ");
    System.out.println("                @@                =@@ @@@                @@@@@             @@                        ");
    System.out.println("                @@                @@    @@@             #@@ @@             @@                        ");
    System.out.println("                =@@              @@@      @@@           @#  @@@            @@                        ");
    System.out.println("                 @@            :@@@@        @@              *@@@@          @@                        ");
    System.out.println("                 @@%         @@@*@@@        @@%     @@@      @@*@@@        @@                        ");
    System.out.println("                 @@@   @@@@@@%   @@          @@   %@@        @@    @@@@@@  @@                        ");
    System.out.println("                 @@@@+  @@+       @@          @@ @@@          @@#       @@- @@@@                     ");
    System.out.println("                -@@@@@@@@        @@         @@@@@             @@       @@@@@@@@                      ");
    System.out.println("                 @@@@  @@       @@@        @@@ @@             @@       @@  @@@                       ");
    System.out.println("                   =@@ @@      *@@             @@             @@@      @@  @@                        ");
    System.out.println("                       @@*   @@@@@             @@             @@@@@#   @@  @@                        ");
    System.out.println("                       %@@@@@  @@@             @@              @@  @@@@@@  @@                        ");
    System.out.println("                               @@:             @@              @@          @@                        ");
    System.out.println("                               @@              @@              @@          @@                        ");
    System.out.println("                               @@              @@              %@@         @@                        ");
    System.out.println("                              @@@              @@               @@         @@                        ");
    System.out.println("                               @@               @@               @@         @@                       ");
    System.out.println("                               @@                %               @@+        @@                       ");
    System.out.println("                             @@                                 @@        @@                         ");
    System.out.println("                            @@@                                 @@        @@                         ");
    System.out.println("                             @@                @@                @@        @@                        ");
    System.out.println("                             @@                @@                @@@       @@                        ");
    System.out.println("                             @@                @@                 @@       @@                        ");
    System.out.println("                            @@=                @@                 @@       @@                        ");
    System.out.println("                            @@                 @@                 @@       @@                        ");
    System.out.println("                            @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@      @@                        ");
    System.out.println("                             @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@# 		            ");

      }
    @Override
    String falar() {
        System.out.println("Digite a frase de efeito do Mago");
        Scanner f = new Scanner(System.in);
        fEfeito = f.next();
        return null;
    }
    @Override
    String arma() {
        System.out.println("ARMA: " + arma);
        return arma;
    }
    @Override
    String setArma() {
           arma = jogM.escolhaArma();
//        //System.out.println("SET ARMA: MAGO");
        return null;
    }
    @Override
    void correr() {
        System.out.println("CORRER: MAGO");
    }

    @Override
    int habilidadeNO() {
        int h = 8;
       return h;
    }

    
}
